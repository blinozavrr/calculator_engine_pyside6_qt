import sys
import math
from math import factorial, log, cos, radians
from PySide6.QtWidgets import QApplication, QMainWindow
from design import Ui_mainWindow

class Calculator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_mainWindow()
        self.ui.setupUi(self)
        self.connect_signals()

    def connect_signals(self):
        # Подключение кнопок к их функциям
        self.ui.btn_0.clicked.connect(lambda: self.add_digit('0'))
        self.ui.btn_1.clicked.connect(lambda: self.add_digit('1'))
        self.ui.btn_2.clicked.connect(lambda: self.add_digit('2'))
        self.ui.btn_3.clicked.connect(lambda: self.add_digit('3'))
        self.ui.btn_4.clicked.connect(lambda: self.add_digit('4'))
        self.ui.btn_5.clicked.connect(lambda: self.add_digit('5'))
        self.ui.btn_6.clicked.connect(lambda: self.add_digit('6'))
        self.ui.btn_7.clicked.connect(lambda: self.add_digit('7'))
        self.ui.btn_8.clicked.connect(lambda: self.add_digit('8'))
        self.ui.btn_9.clicked.connect(lambda: self.add_digit('9'))

        self.ui.btn_plus.clicked.connect(lambda: self.add_operation('+'))
        self.ui.minus.clicked.connect(lambda: self.add_operation('-'))
        self.ui.multipl.clicked.connect(lambda: self.add_operation('*'))
        self.ui.division.clicked.connect(lambda: self.add_operation('/'))

        self.ui.btn_result.clicked.connect(self.calculate_result)
        self.ui.btn_clean.clicked.connect(self.clear_all)
        self.ui.dot.clicked.connect(lambda: self.add_digit('.'))

        self.ui.btn_sqr.clicked.connect(self.square)
        self.ui.btn_cos.clicked.connect(self.cosine)
        self.ui.btn_sin.clicked.connect(self.sine)
        self.ui.btn_tan.clicked.connect(self.tangent)
        self.ui.btn_ln.clicked.connect(self.natural_log)
        self.ui.btn_ctg.clicked.connect(self.cotangent)

        self.ui.percent.clicked.connect(self.percentage)
        self.ui.btn_c1.clicked.connect(lambda: self.add_digit('('))
        self.ui.btn_c2.clicked.connect(lambda: self.add_digit(')'))
        self.ui.btn_bsk.clicked.connect(self.backspace)
        self.ui.btn_fac.clicked.connect(self.factorial)
        self.ui.btn_xcubed.clicked.connect(self.cubed)

    def add_digit(self, digit):
        self.ui.lineEdit.insert(digit)

    def add_operation(self, operation):
        self.ui.lineEdit.insert(operation)

    def calculate_result(self):
        text = self.ui.lineEdit.text()
        try:

            result = eval(text)
            self.ui.lineEdit.setText(str(result))
        except Exception as e:
            self.ui.lineEdit.setText('Error')

    def clear_all(self):
        self.ui.lineEdit.clear()

    def square(self):
        try:
            value = float(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(value ** 2))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    def cosine(self):
        try:
            value = float(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(cos(radians(value))))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    # Добавьте остальные тригонометрические функции по аналогии

    def natural_log(self):
        try:
            value = float(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(log(value)))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    # Добавьте обработку кнопки cotangent

    def percentage(self):
        try:
            value = float(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(value / 100))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    def backspace(self):
        text = self.ui.lineEdit.text()
        self.ui.lineEdit.setText(text[:-1])

    def factorial(self):
        try:
            value = int(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(factorial(value)))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    def cubed(self):
        try:
            value = float(self.ui.lineEdit.text())
            self.ui.lineEdit.setText(str(value ** 3))
        except ValueError:
            self.ui.lineEdit.setText('Error')

    def sine(self):
            # Получаем текущее значение из lineEdit
            value = float(self.ui.lineEdit.text())
            # Вычисляем синус этого значения
            result = math.sin(math.radians(value))
            # Отображаем результат обратно в lineEdit
            self.ui.lineEdit.setText(str(result))

    def tangent(self):
        # Получаем текущее значение из lineEdit
        current_value = self.ui.lineEdit.text()
        # Вычисляем тангенс этого значения
        result = str(math.tan(math.radians(float(current_value))))
        # Устанавливаем результат в lineEdit
        self.ui.lineEdit.setText(result)

    # Функция для котангенса
    def cotangent(self):
        # Получаем текущее значение из lineEdit
        current_value = self.ui.lineEdit.text()
        # Вычисляем котангенс (обратное значение тангенса)
        result = str(1 / math.tan(math.radians(float(current_value))))
        # Устанавливаем результат в lineEdit
        self.ui.lineEdit.setText(result)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Calculator()
    window.show()
    sys.exit(app.exec())
