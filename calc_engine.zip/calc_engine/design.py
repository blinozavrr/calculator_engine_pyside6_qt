

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QLabel, QLayout,
    QLineEdit, QMainWindow, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)
#import rec_rc

class Ui_mainWindow(object):
    def setupUi(self, mainWindow):
        if not mainWindow.objectName():
            mainWindow.setObjectName(u"mainWindow")
        mainWindow.resize(617, 392)
        mainWindow.setMinimumSize(QSize(300, 200))
        font = QFont()
        font.setFamilies([u"Montserat"])
        font.setPointSize(16)
        font.setBold(True)
        mainWindow.setFont(font)
        mainWindow.setFocusPolicy(Qt.NoFocus)
        icon = QIcon()
        icon.addFile(u":/icon/calculator.svg", QSize(), QIcon.Normal, QIcon.Off)
        mainWindow.setWindowIcon(icon)
        mainWindow.setStyleSheet(u"QWidget {\n"
"	color: white;\n"
"	background-color: #05131a;\n"
"	font-family: Montserat;\n"
"	font-size: 16pt;\n"
"	font-weight: 600;\n"
"}\n"
"QPushButton {\n"
"	background-color: #072e33;\n"
"	border:none ;\n"
"}\n"
"QPushButton:hover {\n"
"	background-color: #0c7075;\n"
"}\n"
"QPushButton:pressed {\n"
"	background-color: #6da5c0;\n"
"}")
        mainWindow.setIconSize(QSize(30, 30))
        mainWindow.setDockNestingEnabled(False)
        self.centralwidget = QWidget(mainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setStyleSheet(u"")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color:#888;")
        self.label.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout.addWidget(self.label)

        self.lineEdit = QLineEdit(self.centralwidget)
        self.lineEdit.setObjectName(u"lineEdit")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.lineEdit.sizePolicy().hasHeightForWidth())
        self.lineEdit.setSizePolicy(sizePolicy1)
        font1 = QFont()
        font1.setFamilies([u"Montserat"])
        font1.setPointSize(40)
        font1.setBold(True)
        self.lineEdit.setFont(font1)
        self.lineEdit.setStyleSheet(u"font-size: 40pt;\n"
"border:none;")
        self.lineEdit.setMaxLength(10)
        self.lineEdit.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.lineEdit.setReadOnly(True)

        self.verticalLayout.addWidget(self.lineEdit)

        self.btns = QGridLayout()
        self.btns.setObjectName(u"btns")
        self.btns.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.btn_4 = QPushButton(self.centralwidget)
        self.btn_4.setObjectName(u"btn_4")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.btn_4.sizePolicy().hasHeightForWidth())
        self.btn_4.setSizePolicy(sizePolicy2)
        self.btn_4.setFont(font)
        self.btn_4.setInputMethodHints(Qt.ImhNone)
        self.btn_4.setAutoDefault(False)
        self.btn_4.setFlat(False)

        self.btns.addWidget(self.btn_4, 3, 2, 1, 1)

        self.btn_sin = QPushButton(self.centralwidget)
        self.btn_sin.setObjectName(u"btn_sin")
        sizePolicy2.setHeightForWidth(self.btn_sin.sizePolicy().hasHeightForWidth())
        self.btn_sin.setSizePolicy(sizePolicy2)
        self.btn_sin.setFont(font)
        self.btn_sin.setInputMethodHints(Qt.ImhNone)
        self.btn_sin.setAutoDefault(False)
        self.btn_sin.setFlat(False)

        self.btns.addWidget(self.btn_sin, 2, 0, 1, 1)

        self.btn_c1 = QPushButton(self.centralwidget)
        self.btn_c1.setObjectName(u"btn_c1")
        sizePolicy2.setHeightForWidth(self.btn_c1.sizePolicy().hasHeightForWidth())
        self.btn_c1.setSizePolicy(sizePolicy2)
        self.btn_c1.setFont(font)
        self.btn_c1.setInputMethodHints(Qt.ImhNone)
        self.btn_c1.setAutoDefault(False)
        self.btn_c1.setFlat(False)

        self.btns.addWidget(self.btn_c1, 5, 0, 1, 1)

        self.btn_xcubed = QPushButton(self.centralwidget)
        self.btn_xcubed.setObjectName(u"btn_xcubed")
        sizePolicy2.setHeightForWidth(self.btn_xcubed.sizePolicy().hasHeightForWidth())
        self.btn_xcubed.setSizePolicy(sizePolicy2)
        self.btn_xcubed.setFont(font)
        self.btn_xcubed.setInputMethodHints(Qt.ImhNone)
        self.btn_xcubed.setAutoDefault(False)
        self.btn_xcubed.setFlat(False)

        self.btns.addWidget(self.btn_xcubed, 4, 0, 1, 1)

        self.btn_fac = QPushButton(self.centralwidget)
        self.btn_fac.setObjectName(u"btn_fac")
        sizePolicy2.setHeightForWidth(self.btn_fac.sizePolicy().hasHeightForWidth())
        self.btn_fac.setSizePolicy(sizePolicy2)
        self.btn_fac.setFont(font)
        self.btn_fac.setInputMethodHints(Qt.ImhNone)
        self.btn_fac.setAutoDefault(False)
        self.btn_fac.setFlat(False)

        self.btns.addWidget(self.btn_fac, 3, 0, 1, 1)

        self.btn_cos = QPushButton(self.centralwidget)
        self.btn_cos.setObjectName(u"btn_cos")
        sizePolicy2.setHeightForWidth(self.btn_cos.sizePolicy().hasHeightForWidth())
        self.btn_cos.setSizePolicy(sizePolicy2)
        self.btn_cos.setFont(font)
        self.btn_cos.setInputMethodHints(Qt.ImhNone)
        self.btn_cos.setAutoDefault(False)
        self.btn_cos.setFlat(False)

        self.btns.addWidget(self.btn_cos, 0, 0, 1, 1)

        self.btn_0 = QPushButton(self.centralwidget)
        self.btn_0.setObjectName(u"btn_0")
        sizePolicy2.setHeightForWidth(self.btn_0.sizePolicy().hasHeightForWidth())
        self.btn_0.setSizePolicy(sizePolicy2)
        self.btn_0.setFont(font)
        self.btn_0.setInputMethodHints(Qt.ImhNone)
        self.btn_0.setAutoDefault(False)
        self.btn_0.setFlat(False)

        self.btns.addWidget(self.btn_0, 5, 2, 1, 2)

        self.btn_bsk = QPushButton(self.centralwidget)
        self.btn_bsk.setObjectName(u"btn_bsk")
        sizePolicy2.setHeightForWidth(self.btn_bsk.sizePolicy().hasHeightForWidth())
        self.btn_bsk.setSizePolicy(sizePolicy2)
        self.btn_bsk.setFont(font)
        self.btn_bsk.setInputMethodHints(Qt.ImhNone)
        icon1 = QIcon()
        icon1.addFile(u"icons/backspace.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_bsk.setIcon(icon1)
        self.btn_bsk.setIconSize(QSize(25, 25))
        self.btn_bsk.setAutoDefault(False)
        self.btn_bsk.setFlat(False)

        self.btns.addWidget(self.btn_bsk, 0, 4, 1, 1)

        self.btn_5 = QPushButton(self.centralwidget)
        self.btn_5.setObjectName(u"btn_5")
        sizePolicy2.setHeightForWidth(self.btn_5.sizePolicy().hasHeightForWidth())
        self.btn_5.setSizePolicy(sizePolicy2)
        self.btn_5.setFont(font)
        self.btn_5.setInputMethodHints(Qt.ImhNone)
        self.btn_5.setAutoDefault(False)
        self.btn_5.setFlat(False)

        self.btns.addWidget(self.btn_5, 3, 3, 1, 1)

        self.btn_9 = QPushButton(self.centralwidget)
        self.btn_9.setObjectName(u"btn_9")
        sizePolicy2.setHeightForWidth(self.btn_9.sizePolicy().hasHeightForWidth())
        self.btn_9.setSizePolicy(sizePolicy2)
        self.btn_9.setFont(font)
        self.btn_9.setInputMethodHints(Qt.ImhNone)
        self.btn_9.setAutoDefault(False)
        self.btn_9.setFlat(False)

        self.btns.addWidget(self.btn_9, 2, 4, 1, 1)

        self.division = QPushButton(self.centralwidget)
        self.division.setObjectName(u"division")
        sizePolicy2.setHeightForWidth(self.division.sizePolicy().hasHeightForWidth())
        self.division.setSizePolicy(sizePolicy2)
        self.division.setFont(font)
        self.division.setInputMethodHints(Qt.ImhNone)
        self.division.setAutoDefault(False)
        self.division.setFlat(False)

        self.btns.addWidget(self.division, 0, 5, 1, 1)

        self.btn_8 = QPushButton(self.centralwidget)
        self.btn_8.setObjectName(u"btn_8")
        sizePolicy2.setHeightForWidth(self.btn_8.sizePolicy().hasHeightForWidth())
        self.btn_8.setSizePolicy(sizePolicy2)
        self.btn_8.setFont(font)
        self.btn_8.setInputMethodHints(Qt.ImhNone)
        self.btn_8.setAutoDefault(False)
        self.btn_8.setFlat(False)

        self.btns.addWidget(self.btn_8, 2, 3, 1, 1)

        self.btn_tan = QPushButton(self.centralwidget)
        self.btn_tan.setObjectName(u"btn_tan")
        sizePolicy2.setHeightForWidth(self.btn_tan.sizePolicy().hasHeightForWidth())
        self.btn_tan.setSizePolicy(sizePolicy2)
        self.btn_tan.setFont(font)
        self.btn_tan.setInputMethodHints(Qt.ImhNone)
        self.btn_tan.setAutoDefault(False)
        self.btn_tan.setFlat(False)

        self.btns.addWidget(self.btn_tan, 0, 1, 1, 1)

        self.btn_clean = QPushButton(self.centralwidget)
        self.btn_clean.setObjectName(u"btn_clean")
        sizePolicy2.setHeightForWidth(self.btn_clean.sizePolicy().hasHeightForWidth())
        self.btn_clean.setSizePolicy(sizePolicy2)
        self.btn_clean.setFont(font)
        self.btn_clean.setInputMethodHints(Qt.ImhNone)
        self.btn_clean.setAutoDefault(False)
        self.btn_clean.setFlat(False)

        self.btns.addWidget(self.btn_clean, 0, 2, 1, 1)

        self.btn_7 = QPushButton(self.centralwidget)
        self.btn_7.setObjectName(u"btn_7")
        sizePolicy2.setHeightForWidth(self.btn_7.sizePolicy().hasHeightForWidth())
        self.btn_7.setSizePolicy(sizePolicy2)
        self.btn_7.setFont(font)
        self.btn_7.setInputMethodHints(Qt.ImhNone)
        self.btn_7.setAutoDefault(False)
        self.btn_7.setFlat(False)

        self.btns.addWidget(self.btn_7, 2, 2, 1, 1)

        self.btn_c2 = QPushButton(self.centralwidget)
        self.btn_c2.setObjectName(u"btn_c2")
        sizePolicy2.setHeightForWidth(self.btn_c2.sizePolicy().hasHeightForWidth())
        self.btn_c2.setSizePolicy(sizePolicy2)
        self.btn_c2.setFont(font)
        self.btn_c2.setInputMethodHints(Qt.ImhNone)
        self.btn_c2.setAutoDefault(False)
        self.btn_c2.setFlat(False)

        self.btns.addWidget(self.btn_c2, 5, 1, 1, 1)

        self.btn_ln = QPushButton(self.centralwidget)
        self.btn_ln.setObjectName(u"btn_ln")
        sizePolicy2.setHeightForWidth(self.btn_ln.sizePolicy().hasHeightForWidth())
        self.btn_ln.setSizePolicy(sizePolicy2)
        self.btn_ln.setFont(font)
        self.btn_ln.setInputMethodHints(Qt.ImhNone)
        self.btn_ln.setAutoDefault(False)
        self.btn_ln.setFlat(False)

        self.btns.addWidget(self.btn_ln, 3, 1, 1, 1)

        self.btn_ctg = QPushButton(self.centralwidget)
        self.btn_ctg.setObjectName(u"btn_ctg")
        sizePolicy2.setHeightForWidth(self.btn_ctg.sizePolicy().hasHeightForWidth())
        self.btn_ctg.setSizePolicy(sizePolicy2)
        self.btn_ctg.setFont(font)
        self.btn_ctg.setInputMethodHints(Qt.ImhNone)
        self.btn_ctg.setAutoDefault(False)
        self.btn_ctg.setFlat(False)

        self.btns.addWidget(self.btn_ctg, 2, 1, 1, 1)

        self.multipl = QPushButton(self.centralwidget)
        self.multipl.setObjectName(u"multipl")
        sizePolicy2.setHeightForWidth(self.multipl.sizePolicy().hasHeightForWidth())
        self.multipl.setSizePolicy(sizePolicy2)
        self.multipl.setFont(font)
        self.multipl.setInputMethodHints(Qt.ImhNone)
        self.multipl.setAutoDefault(False)
        self.multipl.setFlat(False)

        self.btns.addWidget(self.multipl, 2, 5, 1, 1)

        self.btn_1 = QPushButton(self.centralwidget)
        self.btn_1.setObjectName(u"btn_1")
        sizePolicy2.setHeightForWidth(self.btn_1.sizePolicy().hasHeightForWidth())
        self.btn_1.setSizePolicy(sizePolicy2)
        self.btn_1.setFont(font)
        self.btn_1.setInputMethodHints(Qt.ImhNone)
        self.btn_1.setAutoDefault(False)
        self.btn_1.setFlat(False)

        self.btns.addWidget(self.btn_1, 4, 2, 1, 1)

        self.btn_sqr = QPushButton(self.centralwidget)
        self.btn_sqr.setObjectName(u"btn_sqr")
        sizePolicy2.setHeightForWidth(self.btn_sqr.sizePolicy().hasHeightForWidth())
        self.btn_sqr.setSizePolicy(sizePolicy2)
        self.btn_sqr.setFont(font)
        self.btn_sqr.setInputMethodHints(Qt.ImhNone)
        self.btn_sqr.setAutoDefault(False)
        self.btn_sqr.setFlat(False)

        self.btns.addWidget(self.btn_sqr, 4, 1, 1, 1)

        self.dot = QPushButton(self.centralwidget)
        self.dot.setObjectName(u"dot")
        sizePolicy2.setHeightForWidth(self.dot.sizePolicy().hasHeightForWidth())
        self.dot.setSizePolicy(sizePolicy2)
        self.dot.setFont(font)
        self.dot.setInputMethodHints(Qt.ImhNone)
        self.dot.setAutoDefault(False)
        self.dot.setFlat(False)

        self.btns.addWidget(self.dot, 5, 4, 1, 1)

        self.btn_result = QPushButton(self.centralwidget)
        self.btn_result.setObjectName(u"btn_result")
        sizePolicy2.setHeightForWidth(self.btn_result.sizePolicy().hasHeightForWidth())
        self.btn_result.setSizePolicy(sizePolicy2)
        self.btn_result.setFont(font)
        self.btn_result.setInputMethodHints(Qt.ImhNone)
        self.btn_result.setAutoDefault(False)
        self.btn_result.setFlat(False)

        self.btns.addWidget(self.btn_result, 5, 5, 1, 1)

        self.btn_3 = QPushButton(self.centralwidget)
        self.btn_3.setObjectName(u"btn_3")
        sizePolicy2.setHeightForWidth(self.btn_3.sizePolicy().hasHeightForWidth())
        self.btn_3.setSizePolicy(sizePolicy2)
        self.btn_3.setFont(font)
        self.btn_3.setInputMethodHints(Qt.ImhNone)
        self.btn_3.setAutoDefault(False)
        self.btn_3.setFlat(False)

        self.btns.addWidget(self.btn_3, 4, 4, 1, 1)

        self.minus = QPushButton(self.centralwidget)
        self.minus.setObjectName(u"minus")
        sizePolicy2.setHeightForWidth(self.minus.sizePolicy().hasHeightForWidth())
        self.minus.setSizePolicy(sizePolicy2)
        self.minus.setFont(font)
        self.minus.setInputMethodHints(Qt.ImhNone)
        self.minus.setAutoDefault(False)
        self.minus.setFlat(False)

        self.btns.addWidget(self.minus, 3, 5, 1, 1)

        self.btn_6 = QPushButton(self.centralwidget)
        self.btn_6.setObjectName(u"btn_6")
        sizePolicy2.setHeightForWidth(self.btn_6.sizePolicy().hasHeightForWidth())
        self.btn_6.setSizePolicy(sizePolicy2)
        self.btn_6.setFont(font)
        self.btn_6.setInputMethodHints(Qt.ImhNone)
        self.btn_6.setAutoDefault(False)
        self.btn_6.setFlat(False)

        self.btns.addWidget(self.btn_6, 3, 4, 1, 1)

        self.btn_plus = QPushButton(self.centralwidget)
        self.btn_plus.setObjectName(u"btn_plus")
        sizePolicy2.setHeightForWidth(self.btn_plus.sizePolicy().hasHeightForWidth())
        self.btn_plus.setSizePolicy(sizePolicy2)
        self.btn_plus.setFont(font)
        self.btn_plus.setInputMethodHints(Qt.ImhNone)
        self.btn_plus.setAutoDefault(False)
        self.btn_plus.setFlat(False)

        self.btns.addWidget(self.btn_plus, 4, 5, 1, 1)

        self.btn_2 = QPushButton(self.centralwidget)
        self.btn_2.setObjectName(u"btn_2")
        sizePolicy2.setHeightForWidth(self.btn_2.sizePolicy().hasHeightForWidth())
        self.btn_2.setSizePolicy(sizePolicy2)
        self.btn_2.setFont(font)
        self.btn_2.setInputMethodHints(Qt.ImhNone)
        self.btn_2.setAutoDefault(False)
        self.btn_2.setFlat(False)

        self.btns.addWidget(self.btn_2, 4, 3, 1, 1)

        self.percent = QPushButton(self.centralwidget)
        self.percent.setObjectName(u"percent")
        sizePolicy2.setHeightForWidth(self.percent.sizePolicy().hasHeightForWidth())
        self.percent.setSizePolicy(sizePolicy2)
        self.percent.setFont(font)
        self.percent.setInputMethodHints(Qt.ImhNone)
        self.percent.setAutoDefault(False)
        self.percent.setFlat(False)

        self.btns.addWidget(self.percent, 0, 3, 1, 1)


        self.verticalLayout.addLayout(self.btns)

        mainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(mainWindow)

        self.btn_4.setDefault(False)
        self.btn_sin.setDefault(False)
        self.btn_c1.setDefault(False)
        self.btn_xcubed.setDefault(False)
        self.btn_fac.setDefault(False)
        self.btn_cos.setDefault(False)
        self.btn_0.setDefault(False)
        self.btn_bsk.setDefault(False)
        self.btn_5.setDefault(False)
        self.btn_9.setDefault(False)
        self.division.setDefault(False)
        self.btn_8.setDefault(False)
        self.btn_tan.setDefault(False)
        self.btn_clean.setDefault(False)
        self.btn_7.setDefault(False)
        self.btn_c2.setDefault(False)
        self.btn_ln.setDefault(False)
        self.btn_ctg.setDefault(False)
        self.multipl.setDefault(False)
        self.btn_1.setDefault(False)
        self.btn_sqr.setDefault(False)
        self.dot.setDefault(False)
        self.btn_result.setDefault(False)
        self.btn_3.setDefault(False)
        self.minus.setDefault(False)
        self.btn_6.setDefault(False)
        self.btn_plus.setDefault(False)
        self.btn_2.setDefault(False)
        self.percent.setDefault(False)


        QMetaObject.connectSlotsByName(mainWindow)
    # setupUi

    def retranslateUi(self, mainWindow):
        mainWindow.setWindowTitle(QCoreApplication.translate("mainWindow", u"Calc Malika", None))
#if QT_CONFIG(whatsthis)
        mainWindow.setWhatsThis(QCoreApplication.translate("mainWindow", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.label.setText("")
        self.lineEdit.setText(QCoreApplication.translate("mainWindow", u"0", None))
        self.btn_4.setText(QCoreApplication.translate("mainWindow", u"4", None))
        self.btn_sin.setText(QCoreApplication.translate("mainWindow", u"sin", None))
        self.btn_c1.setText(QCoreApplication.translate("mainWindow", u"(", None))
        self.btn_xcubed.setText(QCoreApplication.translate("mainWindow", u"x\u00b3", None))
        self.btn_fac.setText(QCoreApplication.translate("mainWindow", u"n!", None))
        self.btn_cos.setText(QCoreApplication.translate("mainWindow", u"cos", None))
        self.btn_0.setText(QCoreApplication.translate("mainWindow", u"0", None))
        self.btn_bsk.setText("")
        self.btn_5.setText(QCoreApplication.translate("mainWindow", u"5", None))
        self.btn_9.setText(QCoreApplication.translate("mainWindow", u"9", None))
        self.division.setText(QCoreApplication.translate("mainWindow", u"\u00f7", None))
        self.btn_8.setText(QCoreApplication.translate("mainWindow", u"8", None))
        self.btn_tan.setText(QCoreApplication.translate("mainWindow", u"tan", None))
        self.btn_clean.setText(QCoreApplication.translate("mainWindow", u"C", None))
        self.btn_7.setText(QCoreApplication.translate("mainWindow", u"7", None))
        self.btn_c2.setText(QCoreApplication.translate("mainWindow", u")", None))
        self.btn_ln.setText(QCoreApplication.translate("mainWindow", u"ln", None))
        self.btn_ctg.setText(QCoreApplication.translate("mainWindow", u"ctg", None))
        self.multipl.setText(QCoreApplication.translate("mainWindow", u"\u2715", None))
        self.btn_1.setText(QCoreApplication.translate("mainWindow", u"1", None))
        self.btn_sqr.setText(QCoreApplication.translate("mainWindow", u"x\u00b2", None))
        self.dot.setText(QCoreApplication.translate("mainWindow", u",", None))
        self.btn_result.setText(QCoreApplication.translate("mainWindow", u"=", None))
        self.btn_3.setText(QCoreApplication.translate("mainWindow", u"3", None))
        self.minus.setText(QCoreApplication.translate("mainWindow", u"-", None))
        self.btn_6.setText(QCoreApplication.translate("mainWindow", u"6", None))
        self.btn_plus.setText(QCoreApplication.translate("mainWindow", u"+", None))
        self.btn_2.setText(QCoreApplication.translate("mainWindow", u"2", None))
        self.percent.setText(QCoreApplication.translate("mainWindow", u"%", None))
    # retranslateUi

